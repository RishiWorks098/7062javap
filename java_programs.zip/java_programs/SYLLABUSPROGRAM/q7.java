package SYLLABUSPROGRAM;

class q7 { public static void main(String[] args) { int age=20, marks=75; System.out.println(age>18); System.out.println(marks>=50); System.out.println(age>18 && marks>=50); System.out.println(age<18 || marks>=50); System.out.println(!(age>18)); } }
