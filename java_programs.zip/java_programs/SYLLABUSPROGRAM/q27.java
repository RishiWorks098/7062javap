package SYLLABUSPROGRAM;

class Animal27 { void eat(){ System.out.println("Animal eats"); } } class Dog27 extends Animal27 { void bark(){ System.out.println("Dog barks"); } } class Puppy27 extends Dog27 { void play(){ System.out.println("Puppy plays"); } } class q27 { public static void main(String[] args) { Puppy27 puppy=new Puppy27(); puppy.eat(); puppy.bark(); puppy.play(); } }
