package SYLLABUSPROGRAM;

class Student32 {
    public String name = "Rahul";
    private int age = 18;
    protected String course = "Java";

    void displayAge() {
        System.out.println("Age: " + age);
    }
}

class q32 {
    public static void main(String[] args) {
        Student32 student = new Student32();
        System.out.println(student.name);
        student.displayAge();
        System.out.println(student.course);
    }
}
