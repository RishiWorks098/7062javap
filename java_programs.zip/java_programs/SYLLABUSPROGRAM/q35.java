package SYLLABUSPROGRAM;

class q35 { public static void main(String[] args) { try { int num=10; int result=num/0; System.out.println(result); } catch(ArithmeticException e){ System.out.println("Cannot divide by zero"); } } }
