package SYLLABUSPROGRAM;

class Student11 {
    String name;
    int rollNo;

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNo);
    }
}

class q11 {
    public static void main(String[] args) {
        Student11 student = new Student11();
        student.name = "Aman";
        student.rollNo = 102;
        student.display();
    }
}
