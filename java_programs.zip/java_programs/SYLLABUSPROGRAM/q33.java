package SYLLABUSPROGRAM;

class PackageMessage33 { void display(){ System.out.println("This is a user-defined package example"); } } class q33 { public static void main(String[] args) { PackageMessage33 obj=new PackageMessage33(); obj.display(); } }
