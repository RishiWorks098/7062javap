package SYLLABUSPROGRAM;

import SYLLABUSPROGRAM.PackageMessage33;

class q34 {
    public static void main(String[] args) {
        PackageMessage33 obj = new PackageMessage33();
        obj.display();
    }
}
