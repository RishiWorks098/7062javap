package SYLLABUSPROGRAM;

class q1 {
    public static void main(String[] args) {
        System.out.println("Welcome to Java Programming");
    }
}
