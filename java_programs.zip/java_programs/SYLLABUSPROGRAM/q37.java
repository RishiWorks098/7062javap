package SYLLABUSPROGRAM;

class q37 { public static void main(String[] args) { try { int num=10; int result=num/2; System.out.println("Result: "+result); } catch(Exception e){ System.out.println("Exception occurred"); } finally { System.out.println("Finally block always executes"); } } }
