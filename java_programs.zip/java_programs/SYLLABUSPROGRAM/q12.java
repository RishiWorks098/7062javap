package SYLLABUSPROGRAM;

class Student12 {
    String name;
    int rollNo;

    Student12() {
        name = "Rahul";
        rollNo = 101;
    }

    void display() {
        System.out.println(name);
        System.out.println(rollNo);
    }
}

class q12 {
    public static void main(String[] args) {
        Student12 student = new Student12();
        student.display();
    }
}
