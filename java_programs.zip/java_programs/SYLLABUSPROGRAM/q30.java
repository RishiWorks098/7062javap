package SYLLABUSPROGRAM;

interface Camera30 { void takePhoto(); } interface Music30 { void playMusic(); } class Phone30 implements Camera30,Music30 { public void takePhoto(){ System.out.println("Taking photo"); } public void playMusic(){ System.out.println("Playing music"); } } class q30 { public static void main(String[] args) { Phone30 phone=new Phone30(); phone.takePhoto(); phone.playMusic(); } }
