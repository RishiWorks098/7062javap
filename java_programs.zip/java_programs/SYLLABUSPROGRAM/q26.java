package SYLLABUSPROGRAM;

class Animal26 { void eat(){ System.out.println("Animal eats food"); } } class Dog26 extends Animal26 { void bark(){ System.out.println("Dog barks"); } } class q26 { public static void main(String[] args) { Dog26 dog=new Dog26(); dog.eat(); dog.bark(); } }
