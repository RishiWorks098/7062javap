package SYLLABUSPROGRAM;

class Student15 { static String college="ABC College"; String name; Student15(String n){ name=n; } static void displayCollege(){ System.out.println(college); } void display(){ System.out.println(name); } } class q15 { public static void main(String[] args) { Student15 student=new Student15("Rahul"); student.display(); Student15.displayCollege(); } }
