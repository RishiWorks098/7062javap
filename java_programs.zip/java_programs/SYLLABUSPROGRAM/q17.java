package SYLLABUSPROGRAM;

abstract class Shape17 { abstract void calculateArea(); } class Rectangle17 extends Shape17 { int length,width; Rectangle17(int l,int w){ length=l; width=w; } void calculateArea(){ System.out.println("Area: "+(length*width)); } } class q17 { public static void main(String[] args) { Rectangle17 rect=new Rectangle17(10,5); rect.calculateArea(); } }
