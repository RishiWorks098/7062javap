package SYLLABUSPROGRAM;

class Addition14 { int add(int a,int b){ return a+b; } double add(double a,double b){ return a+b; } } class q14 { public static void main(String[] args) { Addition14 obj=new Addition14(); System.out.println(obj.add(10,20)); System.out.println(obj.add(5.5,2.5)); } }
