package SYLLABUSPROGRAM;

class q23 {
    public static void main(String[] args) {
        String str1 = "Hello", str2 = "Java";
        System.out.println("Length: " + str1.length());
        System.out.println("Concat: " + str1.concat(str2));
        System.out.println("Compare: " + str1.compareTo(str2));
    }
}
