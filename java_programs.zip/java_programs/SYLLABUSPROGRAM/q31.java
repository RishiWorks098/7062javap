package SYLLABUSPROGRAM;

class Animal31 { String name="Animal"; void display(){ System.out.println("Parent class method"); } } class Dog31 extends Animal31 { String name="Dog"; void display(){ System.out.println(name); System.out.println(super.name); super.display(); } } class q31 { public static void main(String[] args) { Dog31 dog=new Dog31(); dog.display(); } }
