package SYLLABUSPROGRAM;

class Student10 {
    String name;
    int rollNo;
}

class q10 {
    public static void main(String[] args) {
        Student10 student = new Student10();
        student.name = "Rahul";
        student.rollNo = 101;
        System.out.println(student.name);
        System.out.println(student.rollNo);
    }
}
