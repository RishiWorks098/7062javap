package SYLLABUSPROGRAM;

class Student13 {
    String name;
    int rollNo;

    Student13() {
        name = "Unknown";
        rollNo = 0;
    }

    Student13(String n, int r) {
        name = n;
        rollNo = r;
    }

    void display() {
        System.out.println(name + " " + rollNo);
    }
}

class q13 {
    public static void main(String[] args) {
        Student13 student1 = new Student13();
        Student13 student2 = new Student13("Riya", 103);
        student1.display();
        student2.display();
    }
}
