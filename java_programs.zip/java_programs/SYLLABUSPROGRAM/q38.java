package SYLLABUSPROGRAM;

class q38 {
    static void checkAge(int age) throws Exception {
        if (age < 18) {
            Exception obj = new Exception("Age must be 18 or above");
            throw obj;
        } else
            System.out.println("Eligible");
    }

    public static void main(String[] args) {
        try {
            checkAge(16);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
