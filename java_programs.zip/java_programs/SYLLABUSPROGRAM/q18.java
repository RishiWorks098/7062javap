package SYLLABUSPROGRAM;

class Sample18 {
    protected void finalize() {
        System.out.println("Finalize method called");
    }
}

class q18 {
    public static void main(String[] args) {
        Sample18 obj = new Sample18();
        obj = null;
        System.gc();
        System.out.println("End of program");
    }
}
