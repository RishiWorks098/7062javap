package SYLLABUSPROGRAM;

class Animal29 {
    void sound() {
        System.out.println("Animal makes a sound");
    }
}

class Dog29 extends Animal29 {
    void sound() {
        System.out.println("Dog barks");
    }
}

class q29 {
    public static void main(String[] args) {
        Dog29 dog = new Dog29();
        dog.sound();
    }
}
