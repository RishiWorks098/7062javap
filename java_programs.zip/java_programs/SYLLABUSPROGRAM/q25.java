package SYLLABUSPROGRAM;

class q25 { public static void main(String[] args) { StringBuffer str=new StringBuffer("Java"); str.append(" Programming"); System.out.println(str); str.insert(4," Language"); System.out.println(str); str.delete(4,13); System.out.println(str); } }
