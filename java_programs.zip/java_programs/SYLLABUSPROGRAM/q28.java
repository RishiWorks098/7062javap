package SYLLABUSPROGRAM;

class Animal28 {
    void eat() {
        System.out.println("Animal eats");
    }
}

class Dog28 extends Animal28 {
    void bark() {
        System.out.println("Dog barks");
    }
}

class Cat28 extends Animal28 {
    void meow() {
        System.out.println("Cat meows");
    }
}

class q28 {
    public static void main(String[] args) {
        Dog28 dog = new Dog28();
        Cat28 cat = new Cat28();
        dog.eat();
        dog.bark();
        cat.eat();
        cat.meow();
    }
}
