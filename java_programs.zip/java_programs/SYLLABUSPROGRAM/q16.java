package SYLLABUSPROGRAM;

final class Sample16 {
    final int number = 100;

    final void display() {
        System.out.println(number);
    }
}

class q16 {
    public static void main(String[] args) {
        Sample16 obj = new Sample16();
        obj.display();
    }
}
