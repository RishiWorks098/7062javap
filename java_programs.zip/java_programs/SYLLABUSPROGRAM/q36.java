package SYLLABUSPROGRAM;

class q36 {
    public static void main(String[] args) {
        try {
            int arr[] = { 10, 20, 30 };
            System.out.println(arr[5]);
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic exception");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index out of range");
        } catch (Exception e) {
            System.out.println("Some other exception");
        }
    }
}
