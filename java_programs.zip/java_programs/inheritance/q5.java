package inheritance;

class BankAccount {
    double balance;

    BankAccount(double balance) {
        this.balance = balance;
    }

    void deposit(double amount) {
        balance = balance + amount;
        System.out.println("Deposited: " + amount);
    }

    void withdraw(double amount) {
        if (amount <= balance) {
            balance = balance - amount;
            System.out.println("Withdrawn: " + amount);
        }
        else {
            System.out.println("Insufficient balance");
        }
    }

    void displayBalance() {
        System.out.println("Balance: " + balance);
    }
}

class SavingsAccount extends BankAccount {
    SavingsAccount(double balance) {
        super(balance);
    }

    void withdraw(double amount) {
        if (amount <= balance && balance - amount >= 100) {
            balance = balance - amount;
            System.out.println("Withdrawn: " + amount);
        }
        else {
            System.out.println("Minimum balance of 100 required");
        }
    }
}

class q5 {
    public static void main(String[] args) {
        SavingsAccount savingsAccount = new SavingsAccount(1000);

        savingsAccount.deposit(500);
        savingsAccount.withdraw(1200);
        savingsAccount.withdraw(300);
        savingsAccount.displayBalance();
    }
}
