package inheritance;

class Vehicle {
    String make, model, fuelType;
    int year;
    double fuelEfficiency, maxSpeed;

    Vehicle(String make, String model, int year, String fuelType,
            double fuelEfficiency, double maxSpeed) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.fuelType = fuelType;
        this.fuelEfficiency = fuelEfficiency;
        this.maxSpeed = maxSpeed;
    }

    void displayFuelEfficiency() {
        System.out.println("Fuel Efficiency: " + fuelEfficiency + " km/l");
    }

    void displayDistance(double fuel) {
        System.out.println("Distance for " + fuel + " litres: " + (fuel * fuelEfficiency) + " km");
    }

    void displayMaximumSpeed() {
        System.out.println("Maximum Speed: " + maxSpeed + " km/h");
    }

    void display() {
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
        System.out.println("Fuel Type: " + fuelType);

        displayFuelEfficiency();
        displayDistance(10);
        displayMaximumSpeed();
    }
}

class Truck extends Vehicle {
    Truck(String make, String model, int year, String fuelType) {
        super(make, model, year, fuelType, 5, 100);
    }
}

class Car extends Vehicle {
    Car(String make, String model, int year, String fuelType) {
        super(make, model, year, fuelType, 18, 180);
    }
}

class Motorcycle extends Vehicle {
    Motorcycle(String make, String model, int year, String fuelType) {
        super(make, model, year, fuelType, 40, 120);
    }
}

class q9 {
    public static void main(String[] args) {
        Truck truck = new Truck("Tata", "Truck X", 2024, "Diesel");
        Car car = new Car("Honda", "City", 2023, "Petrol");
        Motorcycle motorcycle = new Motorcycle("Hero", "Splendor", 2022, "Petrol");

        System.out.println("--- Truck Details ---");
        truck.display();

        System.out.println("\n--- Car Details ---");
        car.display();

        System.out.println("\n--- Motorcycle Details ---");
        motorcycle.display();
    }
}
