package inheritance;

class Vehicle {
    void drive() {
        System.out.println("Vehicle is moving");
    }
}

class Car extends Vehicle {
    void drive() {
        System.out.println("Repairing a car");
    }
}

class q2 {
    public static void main(String[] args) {
        Car car = new Car();
        car.drive();
    }
}
