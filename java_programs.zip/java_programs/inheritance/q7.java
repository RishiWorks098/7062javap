package inheritance;

class Person {
    String firstName, lastName;

    Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    void displayFirstName() {
        System.out.println("First Name: " + firstName);
    }

    void displayLastName() {
        System.out.println("Last Name: " + lastName);
    }
}

class Employee extends Person {
    int employeeId;
    String jobTitle;

    Employee(String firstName, String lastName, int employeeId, String jobTitle) {
        super(firstName, lastName);
        this.employeeId = employeeId;
        this.jobTitle = jobTitle;
    }

    void displayEmployeeId() {
        System.out.println("Employee ID: " + employeeId);
    }

    void displayLastName() {
        System.out.println("Last Name: " + lastName + " (" + jobTitle + ")");
    }
}

class q7 {
    public static void main(String[] args) {
        Employee employee = new Employee("Rahul", "Sharma", 101, "Developer");

        employee.displayFirstName();
        employee.displayLastName();
        employee.displayEmployeeId();
    }
}
