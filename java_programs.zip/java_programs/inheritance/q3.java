package inheritance;

class Shape {
    void displayArea() {
        System.out.println("Area: 0");
    }
}

class Rectangle extends Shape {
    double length, breadth;

    Rectangle(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }

    void displayArea() {
        System.out.println("Area: " + (length * breadth));
    }
}

class q3 {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle(10, 5);
        rectangle.displayArea();
    }
}
