package inheritance;

class Employee {
    String name, address, jobTitle;
    double salary;

    Employee(String name, String address, double salary, String jobTitle) {
        this.name = name;
        this.address = address;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }

    void displayBonus() {
        System.out.println("Bonus: " + (salary * 0.10));
    }

    void generateReport() {
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Salary: " + salary);
        System.out.println("Job Title: " + jobTitle);

        displayBonus();
    }

    void manageProjects() {
        System.out.println(name + " is managing general tasks");
    }
}

class Manager extends Employee {
    Manager(String name, String address, double salary) {
        super(name, address, salary, "Manager");
    }

    void displayBonus() {
        System.out.println("Bonus: " + (salary * 0.20));
    }

    void manageProjects() {
        System.out.println(name + " is managing company projects");
    }
}

class Developer extends Employee {
    Developer(String name, String address, double salary) {
        super(name, address, salary, "Developer");
    }

    void displayBonus() {
        System.out.println("Bonus: " + (salary * 0.15));
    }

    void manageProjects() {
        System.out.println(name + " is developing software projects");
    }
}

class Programmer extends Employee {
    Programmer(String name, String address, double salary) {
        super(name, address, salary, "Programmer");
    }

    void displayBonus() {
        System.out.println("Bonus: " + (salary * 0.12));
    }

    void manageProjects() {
        System.out.println(name + " is writing and testing programs");
    }
}

class q10 {
    public static void main(String[] args) {
        Manager manager = new Manager("Amit", "Delhi", 60000);
        Developer developer = new Developer("Ravi", "Mumbai", 50000);
        Programmer programmer = new Programmer("Neha", "Pune", 40000);

        System.out.println("--- Manager Details ---");
        manager.generateReport();
        manager.manageProjects();

        System.out.println("\n--- Developer Details ---");
        developer.generateReport();
        developer.manageProjects();

        System.out.println("\n--- Programmer Details ---");
        programmer.generateReport();
        programmer.manageProjects();
    }
}
