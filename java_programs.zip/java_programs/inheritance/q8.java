package inheritance;

class Shape {
    void displayArea() {
        System.out.println("Area: 0");
    }

    void displayPerimeter() {
        System.out.println("Perimeter: 0");
    }
}

class Circle extends Shape {
    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    void displayArea() {
        System.out.println("Area: " + (Math.PI * radius * radius));
    }

    void displayPerimeter() {
        System.out.println("Perimeter: " + (2 * Math.PI * radius));
    }
}

class q8 {
    public static void main(String[] args) {
        Circle circle = new Circle(5);

        circle.displayArea();
        circle.displayPerimeter();
    }
}
