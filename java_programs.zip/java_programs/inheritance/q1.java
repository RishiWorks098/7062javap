package inheritance;

class Animal {
    void makeSound() {
        System.out.println("Animal makes a sound");
    }
}

class Cat extends Animal {
    void makeSound() {
        System.out.println("Cat meows");
    }
}

class q1 {
    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.makeSound();
    }
}
