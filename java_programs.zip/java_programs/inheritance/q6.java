package inheritance;

class Animal {
    void move() {
        System.out.println("Animal moves");
    }
}

class Cheetah extends Animal {
    void move() {
        System.out.println("Cheetah runs very fast");
    }
}

class q6 {
    public static void main(String[] args) {
        Cheetah cheetah = new Cheetah();
        cheetah.move();
    }
}
