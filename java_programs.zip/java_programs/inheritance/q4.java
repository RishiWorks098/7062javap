package inheritance;

class Employee {
    void work() {
        System.out.println("Employee is working");
    }

    void getSalary() {
        System.out.println("Salary is 30000");
    }
}

class HRManager extends Employee {
    void work() {
        System.out.println("HR Manager is managing employees");
    }

    void addEmployee() {
        System.out.println("New employee added");
    }
}

class q4 {
    public static void main(String[] args) {
        HRManager hrManager = new HRManager();
        hrManager.work();
        hrManager.getSalary();
        hrManager.addEmployee();
    }
}
