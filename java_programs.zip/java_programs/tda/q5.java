package tda;import java.util.Scanner;

class q5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int row, col;
        boolean equal = true;

        System.out.println("Enter rows and columns : ");
        row = sc.nextInt();
        col = sc.nextInt();

        int mat1[][] = new int[row][col];
        int mat2[][] = new int[row][col];

        System.out.println("Enter first matrix : ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                mat1[i][j] = sc.nextInt();
            }
        }

        System.out.println("Enter second matrix : ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                mat2[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < row && equal; i++) {
            for (int j = 0; j < col; j++) {
                if (mat1[i][j] != mat2[i][j]) {
                    equal = false;
                    break ;
                }
            }
        }

        if (equal == true) {
            System.out.println("Matrices are equal");
        }
        else {
            System.out.println("Matrices are not equal");
        }

        sc.close();
    }
}