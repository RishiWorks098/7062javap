package tda;
import java.util.Scanner;

class q3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int row, col;

        System.out.println("Enter rows and columns : ");
        row = sc.nextInt();
        col = sc.nextInt();

        int mat1[][] = new int[row][col];
        int mat2[][] = new int[row][col];
        int sum[][] = new int[row][col];

        System.out.println("Enter first matrix : ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
               mat1[i][j] = sc.nextInt();
            }
        }

        System.out.println("Enter second matrix : ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
               mat2[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i <  row; i++) {
            for (int j = 0; j < col; j++) {
                sum[i][j] =mat1[i][j] * mat2[i][j];
            }
        }

        System.out.println("Multpilication of matrices : ");
        for (int i = 0; i <  row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.print(sum[i][j] + " ");
            }
            System.out.println();
        }
        sc.close();
    }
}

