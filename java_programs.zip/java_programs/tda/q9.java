package tda;
import java.util.Scanner;

class q9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int row, col;

        System.out.println("Enter rows and columns : ");
        row = sc.nextInt();
        col = sc.nextInt();

        int mat[][] = new int[row][col];

        System.out.println("Enter matrix elements : ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                mat[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < row; i++) {
            int sum = 0;

            for (int j = 0; j < col; j++) {
                sum = sum + mat[i][j];
            }

            System.out.println("Sum of row " + (i + 1) + " : " + sum);
        }

        for (int j = 0; j < col; j++) {
            int sum = 0;

            for (int i = 0; i < row; i++) {
                sum = sum + mat[i][j];
            }

            System.out.println("Sum of column " + (j + 1) + " : " + sum);
        }
        sc.close();
    }
}
