package tda;
import java.util.Scanner;

class q10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int row, col;

        System.out.println("Enter rows and columns : ");
        row = sc.nextInt();
        col = sc.nextInt();

        int mat[][] = new int[row][col];
        int trans[][] = new int[col][row];

        System.out.println("Enter matrix elements : ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                mat[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                trans[j][i] = mat[i][j];
            }
        }

        System.out.println("Transpose of matrix : ");
        for (int i = 0; i < col; i++) {
            for (int j = 0; j < row; j++) {
                System.out.print(trans[i][j] + " ");
            }
            System.out.println();
        }
        sc.close();
    }
}
