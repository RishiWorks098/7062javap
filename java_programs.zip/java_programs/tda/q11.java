package tda;
import java.util.Scanner;

class q12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n;
        boolean identity = true;

        System.out.println("Enter order of matrix : ");
        n = sc.nextInt();

        int mat[][] = new int[n][n];

        System.out.println("Enter matrix elements : ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j && mat[i][j] != 1) {
                    identity = false;
                }
                else if (i != j && mat[i][j] != 0) {
                    identity = false;
                }
            }
        }

        if (identity == true) {
            System.out.println("Matrix is an identity matrix");
        }
        else {
            System.out.println("Matrix is not an identity matrix");
        }
        sc.close();
    }
}
