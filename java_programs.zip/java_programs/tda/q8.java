package tda;
import java.util.Scanner;


class q8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int row, col;
        int odd = 0, even = 0;

        System.out.println("Enter rows and columns : ");
        row = sc.nextInt();
        col = sc.nextInt();

        int mat[][] = new int[row][col];

        System.out.println("Enter matrix elements : ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                mat[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (mat[i][j] % 2 == 0) {
                    even++;
                }
                else {
                    odd++;
                }
            }
        }

        System.out.println("Frequency of even numbers : " + even);
        System.out.println("Frequency of odd numbers : " + odd);
        sc.close();
    }
}
