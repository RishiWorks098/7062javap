package method;

class q9 {

    static boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }

        return true;
    }

    static void twinPrime() {
        System.out.println("Twin prime numbers less than 100 : ");

        for (int i = 2; i < 100; i++) {
            if (isPrime(i) && isPrime(i + 2) && i + 2 < 100) {
                System.out.println("(" + i + ", " + (i + 2) + ")");
            }
        }
    }

    public static void main(String[] args) {
        twinPrime();
    }
}
