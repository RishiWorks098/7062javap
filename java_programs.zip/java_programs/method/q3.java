package method;

import java.util.Scanner;

class q3 {

    static void middle(String str) {
        int len = str.length();

        if (len == 0) {
            System.out.println("Empty string");
        }
        else if (len % 2 == 0) {
            System.out.println("Middle characters : "
                    + str.charAt(len / 2 - 1)
                    + str.charAt(len / 2));
        }
        else {
            System.out.println("Middle character : "
                    + str.charAt(len / 2));
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();

        middle(str);
        sc.close();
    
    }
}
