package method;

import java.util.Scanner;

class q10 {

    static int countTwo(int num) {
        int count = 0;

        while (num > 0) {
            int digit = num % 10;

            if (digit == 2) {
                count++;
            }

            num = num / 10;
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a non-negative integer : ");
        int num = sc.nextInt();

        System.out.println("Number of 2 digits : " + countTwo(num));
        sc.close();
    }
}