package method;

import java.util.Scanner;

class q12 {

    static boolean middlePoint(int a, int b, int c) {
        return (a + b == 2 * c ||
                a + c == 2 * b ||
                b + c == 2 * a);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter three integers : ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();

        System.out.println(middlePoint(a, b, c));
        sc.close();
    }
}
