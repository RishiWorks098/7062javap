package method;

import java.util.Scanner;

class q5 {

    static double futureValue(double amount, double rate, int years) {
        double value = amount * Math.pow(1 + rate / 100, years);

        return value;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter investment amount : ");
        double amount = sc.nextDouble();

        System.out.println("Enter interest rate : ");
        double rate = sc.nextDouble();

        System.out.println("Enter number of years : ");
        int years = sc.nextInt();

        System.out.println("Future investment value : " + futureValue(amount, rate, years));
        sc.close();
    }
}
