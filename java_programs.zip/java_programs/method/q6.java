package method;

import java.util.Scanner;

class q6 {

    static void displayCharacters(char start, char end) {
        for (char ch = start; ch <= end; ch++) {
            System.out.print(ch + " ");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter starting character : ");
        char start = sc.next().charAt(0);

        System.out.println("Enter ending character : ");
        char end = sc.next().charAt(0);

        displayCharacters(start, end);
        sc.close();
    }
}