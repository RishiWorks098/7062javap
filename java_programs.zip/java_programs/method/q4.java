package method;

import java.util.Scanner;

class q4 {

    static int countWords(String str) {
        str = str.trim();

        if (str.length() == 0) {
            return 0;
        }

        String words[] = str.split("\\s+");

        return words.length;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();

        System.out.println("Number of words : " + countWords(str));
        sc.close();
    }
}
