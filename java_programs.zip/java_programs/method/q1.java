package method;

import java.util.Scanner;

class q1 {

    static int smallest(int a, int b, int c) {
        int small = a;

        if (b < small) {
            small = b;
        }

        if (c < small) {
            small = c;
        }

        return small;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter three numbers : ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();

        System.out.println("Smallest number : " + smallest(a, b, c));
        sc.close();
    }
}
