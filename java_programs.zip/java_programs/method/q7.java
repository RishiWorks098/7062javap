package method;

import java.util.Scanner;

class q7 {

    static boolean validPassword(String password) {
        boolean upper = false;
        boolean lower = false;
        boolean digit = false;
        boolean special = false;

        if (password.length() < 8) {
            return false;
        }

        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                upper = true;
            }
            else if (Character.isLowerCase(ch)) {
                lower = true;
            }
            else if (Character.isDigit(ch)) {
                digit = true;
            }
            else {
                special = true;
            }
        }

        return upper && lower && digit && special;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter password : ");
        String password = sc.nextLine();

        if (validPassword(password)) {
            System.out.println("Valid password");
        }
        else {
            System.out.println("Invalid password");
        }
        sc.close();
    }
}
