package method;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class q8 {

    static void displayDateTime() {
        LocalDateTime now = LocalDateTime.now();

        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        System.out.println("Current date and time : "  + now.format(format));
    }

    public static void main(String[] args) {
        displayDateTime();
    }
}
