import java.util.Scanner;

class q4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        System.out.println("Enter character to remove : ");
        String input = sc.nextLine();
        if (input.length() == 0) {
            System.out.println("No character entered");
        }
        else {
            char remove = input.charAt(0);
            String result = "";
            for (int i = 0; i < str.length(); i++) {
                if (str.charAt(i) != remove) {
                    result = result + str.charAt(i);
                }
            }
            System.out.println("Result : " + result);
        }

        sc.close();
    }
}
