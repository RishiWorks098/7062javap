import java.util.Scanner;

class q10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        boolean palindrome = true;
        for (int i = 0; i < str.length() / 2 && palindrome == true; i++) {
            if (str.charAt(i) != str.charAt(str.length() - 1 - i)) {
                palindrome = false;
            }
        }
        System.out.println("Palindrome : " + palindrome);

        sc.close();
    }
}
