import java.util.Scanner;

class q11 {

    enum Day {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Day day = Day.MONDAY;
        String str = day.name();
        System.out.println("Enum as string : " + str);

        sc.close();
    }
}
