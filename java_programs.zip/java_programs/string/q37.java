import java.util.Scanner;

class q37 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        String result = "";
        for (int i = 0; i < str.length(); i++) {
            if (Character.isWhitespace(str.charAt(i)) == false) {
                result = result + str.charAt(i);
            }
        }
        System.out.println("Without whitespace : " + result);

        sc.close();
    }
}
