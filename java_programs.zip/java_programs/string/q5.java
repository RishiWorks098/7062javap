import java.util.Scanner;

class q5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first string : ");
        String first = sc.nextLine();
        System.out.println("Enter second string : ");
        String second = sc.nextLine();
        StringBuffer buffer = new StringBuffer(first);
        buffer.append(second);
        System.out.println("Result : " + buffer);

        sc.close();
    }
}
