import java.util.Scanner;

class q40 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        System.out.println("Individual characters : ");
        for (int i = 0; i < str.length(); i++) {
            System.out.println(str.charAt(i));
        }

        sc.close();
    }
}
