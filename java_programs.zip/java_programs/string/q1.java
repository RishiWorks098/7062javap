import java.util.Scanner;

class q1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        boolean digits = true;
        if (str.length() == 0) {
            digits = false;
        }
        for (int i = 0; i < str.length() && digits == true; i++) {
            if (str.charAt(i) < '0' || str.charAt(i) > '9') {
                digits = false;
            }
        }
        System.out.println("Contains only digits : " + digits);

        sc.close();
    }
}
