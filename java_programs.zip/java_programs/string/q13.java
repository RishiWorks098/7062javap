import java.util.Scanner;

class q13 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        String words[];
        if (str.trim().length() == 0) {
            words = new String[0];
        }
        else {
            words = str.trim().split("\\s+");
        }
        System.out.println("Number of words : " + words.length);

        sc.close();
    }
}
