import java.util.Scanner;

class q34 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Hello\nJava");

        sc.close();
    }
}
