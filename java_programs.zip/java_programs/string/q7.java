import java.util.Scanner;

class q7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        System.out.println("Enter a character : ");
        String input = sc.nextLine();
        if (input.length() == 0) {
            System.out.println("No character entered");
        }
        else {
            char ch = input.charAt(0);
            System.out.println("Result : " + str + ch);
        }

        sc.close();
    }
}
