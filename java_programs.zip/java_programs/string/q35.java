import java.util.Scanner;

class q35 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        String words[];
        if (str.trim().length() == 0) {
            words = new String[0];
        }
        else {
            words = str.trim().split("\\s+");
        }
        System.out.println("Even length words : ");
        for (int i = 0; i < words.length; i++) {
            if (words[i].length() % 2 == 0) {
                System.out.println(words[i]);
            }
        }

        sc.close();
    }
}
