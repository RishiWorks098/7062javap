import java.util.Scanner;

class q31 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        System.out.println("Enter character index : ");
        int index = sc.nextInt();
        if (index >= 0 && index < str.length()) {
            System.out.println("Character : " + str.charAt(index));
        }
        else {
            System.out.println("Invalid index");
        }

        sc.close();
    }
}
