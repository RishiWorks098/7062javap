import java.util.Scanner;

class q49 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String str = sc.nextLine();
        StringBuffer buffer = new StringBuffer(str);
        buffer.reverse();
        System.out.println("Reverse : " + buffer);

        sc.close();
    }
}
