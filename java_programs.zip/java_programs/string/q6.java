import java.util.Scanner;

class q6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first string : ");
        String first = sc.nextLine();
        System.out.println("Enter second string : ");
        String second = sc.nextLine();
        System.out.println("Enter insertion index : ");
        int index = sc.nextInt();
        if (index >= 0 && index <= first.length()) {
            StringBuffer buffer = new StringBuffer(first);
            buffer.insert(index, second);
            System.out.println("Result : " + buffer);
        }
        else {
            System.out.println("Invalid index");
        }

        sc.close();
    }
}
