import java.util.Scanner;

class q44 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first string : ");
        String first = sc.nextLine();
        System.out.println("Enter second string : ");
        String second = sc.nextLine();
        System.out.println("First contains second : " + first.contains(second));

        sc.close();
    }
}
