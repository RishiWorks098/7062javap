package EH;

import java.util.Scanner;

class q12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter a number: ");
            int num = Integer.parseInt(sc.nextLine());

            int result = 100 / num;
            System.out.println("Result: " + result);

        } catch (ArithmeticException e) {
            System.out.println("Cannot divide by zero");

        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid integer");

        } catch (Exception e) {
            System.out.println("Some other exception occurred");
        }

        sc.close();
    }
}
