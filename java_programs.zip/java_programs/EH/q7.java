package EH;

import java.util.Scanner;

class q7 {
    static void checkVowels(String str) throws Exception {
        boolean found = false;

        for (int i = 0; i < str.length(); i++) {
            char ch = Character.toLowerCase(str.charAt(i));

            if (ch == 'a' || ch == 'e' || ch == 'i' ||
                ch == 'o' || ch == 'u') {
                found = true;
                break;
            }
        }

        if (found == false) {
            Exception obj = new Exception();
            throw obj;
        } else {
            System.out.println("String contains vowels");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String str = sc.nextLine();

        try {
            checkVowels(str);
        } catch (Exception e) {
            System.out.println("String does not contain vowels");
        }

        sc.close();
    }
}
