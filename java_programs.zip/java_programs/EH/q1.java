package EH;

class q1 {
    public static void main(String[] args) {
        try {
            int num = 10;

            if (num > 0) {
                Exception obj = new Exception();
                throw obj;
            }

        } catch (Exception e) {
            System.out.println("Number is positive");
        }
    }
}
