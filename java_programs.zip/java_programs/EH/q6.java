package EH;

import java.util.Scanner;

class q6 {
    static void checkDuplicate(int arr[]) throws Exception {
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    Exception obj = new Exception();
                    throw obj;
                }
            }
        }

        System.out.println("No duplicate numbers found");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements: ");
        int size = sc.nextInt();

        int arr[] = new int[size];

        System.out.println("Enter numbers:");

        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        try {
            checkDuplicate(arr);
        } catch (Exception e) {
            System.out.println("Duplicate number found: " );
        }

        sc.close();
    }
}
