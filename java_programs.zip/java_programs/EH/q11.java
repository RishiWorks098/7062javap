package EH;

class q11 {
    static void checkAge(int age) throws Exception {
        if (age < 18) {
            Exception obj = new Exception("Not eligible to vote");
            throw obj;
        } else {
            System.out.println("Eligible to vote");
        }
    }

    public static void main(String[] args) {
        try {
            checkAge(16);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
