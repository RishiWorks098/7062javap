package EH;

class q2 {
    static void checkNumber(int num) throws Exception {
        if (num % 2 != 0) {
            Exception obj = new Exception();
            throw obj;
        } else {
            System.out.println("Number is even");
        }
    }

    public static void main(String[] args) {
        try {
            checkNumber(7);
        } catch (Exception e) {
            System.out.println("Number is odd");
        }
    }
}
