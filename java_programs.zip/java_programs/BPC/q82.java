package BPC;

import java.util.Scanner;

class q82 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount, sum = 0;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
            sum = sum + arrayElements[index];
        }

        System.out.println("Sum of array elements : " + sum);

        sc.close();
    }

}
