package BPC;

class q17 {

    public static void main(String[] args) {
        System.out.println("Even numbers from 1 to 20 : ");

        for (int number = 2; number <= 20; number = number + 2) {
            System.out.print(number + " ");
        }
    }

}
