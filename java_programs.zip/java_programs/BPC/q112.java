package BPC;

import java.util.Scanner;

class q112 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number;
        boolean isPrime = true;

        System.out.println("Enter a number : ");
        number = sc.nextInt();

        if (number < 2) {
            isPrime = false;
        }

        for (int divisor = 2; divisor <= number / 2; divisor++) {
            if (number % divisor == 0) {
                isPrime = false;
                break;
            }
        }

        if (isPrime == true) {
            System.out.println(number + " is a prime number");
        }
        else {
            System.out.println(number + " is not a prime number");
        }

        sc.close();
    }

}
