package BPC;

import java.util.Scanner;

class q72 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String inputString;

        System.out.println("Enter a string with spaces : ");
        inputString = sc.nextLine();

        System.out.println("String after trimming : " + inputString.trim());

        sc.close();
    }

}
