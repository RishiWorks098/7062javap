package BPC;

import java.util.Scanner;

class q13 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        char character;

        System.out.println("Enter a character : ");
        character = sc.next().charAt(0);

        System.out.println("ASCII value of " + character + " is : " + (int) character);

        sc.close();
    }

}
