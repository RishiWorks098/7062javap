package BPC;

import java.util.Scanner;

class q35 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double cylinderRadius, cylinderHeight, cylinderVolume;

        System.out.println("Enter radius of cylinder : ");
        cylinderRadius = sc.nextDouble();

        System.out.println("Enter height of cylinder : ");
        cylinderHeight = sc.nextDouble();

        cylinderVolume = 3.14 * cylinderRadius * cylinderRadius * cylinderHeight;

        System.out.println("Volume of cylinder : " + cylinderVolume);

        sc.close();
    }

}
