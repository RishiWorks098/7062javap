package BPC;

import java.util.Scanner;

class q40 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double cubeSide, cubeSurfaceArea;

        System.out.println("Enter side of cube : ");
        cubeSide = sc.nextDouble();

        cubeSurfaceArea = 6 * cubeSide * cubeSide;

        System.out.println("Surface area of cube : " + cubeSurfaceArea);

        sc.close();
    }

}
