package BPC;

import java.util.Scanner;

class q105 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int subjectCount, totalMarks = 0;

        System.out.println("Enter number of subjects : ");
        subjectCount = sc.nextInt();

        int marks[] = new int[subjectCount];

        System.out.println("Enter marks : ");
        for (int subject = 0; subject < subjectCount; subject++) {
            marks[subject] = sc.nextInt();
            totalMarks = totalMarks + marks[subject];
        }

        double percentage = (double) totalMarks / subjectCount;

        System.out.println("Total marks : " + totalMarks);
        System.out.println("Percentage : " + percentage);

        sc.close();
    }

}
