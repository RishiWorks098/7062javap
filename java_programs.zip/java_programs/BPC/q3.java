package BPC;

import java.util.Scanner;

class q3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1, num2, product;

        System.out.println("Enter first number : ");
        num1 = sc.nextInt();

        System.out.println("Enter second number : ");
        num2 = sc.nextInt();

        product = num1 * num2;

        System.out.println("Product of two numbers : " + product);

        sc.close();
    }

}
