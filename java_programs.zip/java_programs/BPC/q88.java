package BPC;

import java.util.Scanner;

class q88 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        System.out.println("Array in reverse order : ");
        for (int index = elementCount - 1; index >= 0; index--) {
            System.out.print(arrayElements[index] + " ");
        }

        sc.close();
    }

}
