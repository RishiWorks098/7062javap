package BPC;

import java.util.Scanner;

class q86 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        int maximum = arrayElements[0];
        int minimum = arrayElements[0];

        for (int index = 1; index < elementCount; index++) {
            if (arrayElements[index] > maximum) {
                maximum = arrayElements[index];
            }

            if (arrayElements[index] < minimum) {
                minimum = arrayElements[index];
            }
        }

        System.out.println("Maximum element : " + maximum);
        System.out.println("Minimum element : " + minimum);

        sc.close();
    }

}
