package BPC;

import java.util.Scanner;

class q59 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        char character;

        System.out.println("Enter a character : ");
        character = sc.next().charAt(0);

        if (character == 'a' || character == 'e' || character == 'i' ||
            character == 'o' || character == 'u' ||
            character == 'A' || character == 'E' || character == 'I' ||
            character == 'O' || character == 'U') {
            System.out.println(character + " is a vowel");
        }
        else {
            System.out.println(character + " is a consonant");
        }

        sc.close();
    }

}
