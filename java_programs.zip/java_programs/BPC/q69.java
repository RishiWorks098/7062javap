package BPC;

import java.util.Scanner;

class q69 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String firstString, secondString;

        System.out.println("Enter first string : ");
        firstString = sc.nextLine();

        System.out.println("Enter second string : ");
        secondString = sc.nextLine();

        System.out.println("Concatenated string : " + firstString + secondString);

        sc.close();
    }

}
