package BPC;

import java.util.Scanner;

class q36 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double cuboidLength, cuboidWidth, cuboidHeight, cuboidVolume;

        System.out.println("Enter length of cuboid : ");
        cuboidLength = sc.nextDouble();

        System.out.println("Enter width of cuboid : ");
        cuboidWidth = sc.nextDouble();

        System.out.println("Enter height of cuboid : ");
        cuboidHeight = sc.nextDouble();

        cuboidVolume = cuboidLength * cuboidWidth * cuboidHeight;

        System.out.println("Volume of cuboid : " + cuboidVolume);

        sc.close();
    }

}
