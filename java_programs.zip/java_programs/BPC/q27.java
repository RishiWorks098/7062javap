package BPC;

import java.util.Scanner;

class q27 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double circleRadius, circleArea;

        System.out.println("Enter radius of circle : ");
        circleRadius = sc.nextDouble();

        circleArea = 3.14 * circleRadius * circleRadius;

        System.out.println("Area of circle : " + circleArea);

        sc.close();
    }

}
