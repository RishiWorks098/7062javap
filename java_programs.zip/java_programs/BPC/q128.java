package BPC;

import java.util.Scanner;

class q128 {

    static boolean isEven(int number) {
        return number % 2 == 0;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number;

        System.out.println("Enter a number : ");
        number = sc.nextInt();

        if (isEven(number)) {
            System.out.println(number + " is an even number");
        }
        else {
            System.out.println(number + " is an odd number");
        }

        sc.close();
    }

}
