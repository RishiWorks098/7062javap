package BPC;

import java.util.Scanner;

class q6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1, num2, temporary;

        System.out.println("Enter first number : ");
        num1 = sc.nextInt();

        System.out.println("Enter second number : ");
        num2 = sc.nextInt();

        temporary = num1;
        num1 = num2;
        num2 = temporary;

        System.out.println("After swapping : ");
        System.out.println("First number : " + num1);
        System.out.println("Second number : " + num2);

        sc.close();
    }

}
