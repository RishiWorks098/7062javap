package BPC;

import java.util.Scanner;

class q60 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int limit;

        System.out.println("Enter a number : ");
        limit = sc.nextInt();

        System.out.println("Cubes of numbers up to " + limit + " : ");

        for (int number = 1; number <= limit; number++) {
            System.out.println(number + " cubed is : " + (number * number * number));
        }

        sc.close();
    }

}
