package BPC;

import java.util.Scanner;

class q43 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int numberCount, sum = 0;

        System.out.println("Enter how many numbers : ");
        numberCount = sc.nextInt();

        int numbers[] = new int[numberCount];

        System.out.println("Enter numbers : ");
        for (int index = 0; index < numberCount; index++) {
            numbers[index] = sc.nextInt();
            sum = sum + numbers[index];
        }

        System.out.println("Sum of N numbers : " + sum);

        sc.close();
    }

}
