package BPC;

import java.util.Scanner;

class q64 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number, digitCount = 0;

        System.out.println("Enter a positive integer : ");
        number = sc.nextInt();

        if (number == 0) {
            digitCount = 1;
        }

        while (number > 0) {
            digitCount++;
            number = number / 10;
        }

        System.out.println("Number of digits : " + digitCount);

        sc.close();
    }

}
