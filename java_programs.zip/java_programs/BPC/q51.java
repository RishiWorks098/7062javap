package BPC;

import java.util.Scanner;

class q51 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int baseNumber, power, result = 1;

        System.out.println("Enter base : ");
        baseNumber = sc.nextInt();

        System.out.println("Enter power : ");
        power = sc.nextInt();

        for (int count = 1; count <= power; count++) {
            result = result * baseNumber;
        }

        System.out.println(baseNumber + " raised to the power " + power + " is : " + result);

        sc.close();
    }

}
