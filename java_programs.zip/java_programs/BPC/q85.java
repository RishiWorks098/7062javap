package BPC;

import java.util.Scanner;

class q85 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount, searchKey;
        boolean isFound = false;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        System.out.println("Enter element to search : ");
        searchKey = sc.nextInt();

        for (int index = 0; index < elementCount; index++) {
            if (arrayElements[index] == searchKey) {
                isFound = true;
                break;
            }
        }

        if (isFound == true) {
            System.out.println("Array contains " + searchKey);
        }
        else {
            System.out.println("Array does not contain " + searchKey);
        }

        sc.close();
    }

}
