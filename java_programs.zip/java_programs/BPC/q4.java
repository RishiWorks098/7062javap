package BPC;

import java.util.Scanner;

class q4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1, num2;

        System.out.println("Enter first number : ");
        num1 = sc.nextInt();

        System.out.println("Enter second number : ");
        num2 = sc.nextInt();

        System.out.println("Sum : " + (num1 + num2));
        System.out.println("Difference : " + (num1 - num2));
        System.out.println("Product : " + (num1 * num2));
        System.out.println("Quotient : " + (num1 / num2));
        System.out.println("Remainder : " + (num1 % num2));

        sc.close();
    }

}
