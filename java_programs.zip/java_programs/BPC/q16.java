package BPC;

class q16 {

    public static void main(String[] args) {
        System.out.println("Odd numbers from 1 to 20 : ");

        for (int number = 1; number <= 20; number = number + 2) {
            System.out.print(number + " ");
        }
    }

}
