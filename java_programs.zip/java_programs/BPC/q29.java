package BPC;

import java.util.Scanner;

class q29 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double triangleBase, triangleHeight, triangleArea;

        System.out.println("Enter base of triangle : ");
        triangleBase = sc.nextDouble();

        System.out.println("Enter height of triangle : ");
        triangleHeight = sc.nextDouble();

        triangleArea = 0.5 * triangleBase * triangleHeight;

        System.out.println("Area of triangle : " + triangleArea);

        sc.close();
    }

}
