package BPC;

import java.util.Scanner;

class q71 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String inputString;

        System.out.println("Enter a string : ");
        inputString = sc.nextLine();

        System.out.println("String in uppercase : " + inputString.toUpperCase());

        sc.close();
    }

}
