package BPC;

import java.util.Scanner;

class q77 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String inputString;
        int characterIndex;

        System.out.println("Enter a string : ");
        inputString = sc.nextLine();

        System.out.println("Enter index : ");
        characterIndex = sc.nextInt();

        if (characterIndex >= 0 && characterIndex < inputString.length()) {
            System.out.println("Character at index " + characterIndex + " is : "
                    + inputString.charAt(characterIndex));
        }
        else {
            System.out.println("Invalid index");
        }

        sc.close();
    }

}
