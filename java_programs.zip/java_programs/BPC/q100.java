package BPC;

import java.util.Scanner;

class q100 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        for (int outer = 0; outer < elementCount - 1; outer++) {
            for (int inner = 0; inner < elementCount - outer - 1; inner++) {
                if (arrayElements[inner] > arrayElements[inner + 1]) {
                    int temporary = arrayElements[inner];
                    arrayElements[inner] = arrayElements[inner + 1];
                    arrayElements[inner + 1] = temporary;
                }
            }
        }

        System.out.println("Array in ascending order : ");
        for (int index = 0; index < elementCount; index++) {
            System.out.print(arrayElements[index] + " ");
        }

        sc.close();
    }

}
