package BPC;

import java.util.Scanner;

class q121 {

    static int smallest(int num1, int num2, int num3) {
        int smallestNumber = num1;

        if (num2 < smallestNumber) {
            smallestNumber = num2;
        }

        if (num3 < smallestNumber) {
            smallestNumber = num3;
        }

        return smallestNumber;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1, num2, num3;

        System.out.println("Enter three numbers : ");
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        num3 = sc.nextInt();

        System.out.println("Smallest number : " + smallest(num1, num2, num3));

        sc.close();
    }

}
