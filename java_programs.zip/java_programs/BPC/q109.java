package BPC;

import java.util.Scanner;

class q109 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number;
        long factorial = 1;

        System.out.println("Enter a number : ");
        number = sc.nextInt();

        for (int multiplier = 1; multiplier <= number; multiplier++) {
            factorial = factorial * multiplier;
        }

        System.out.println("Factorial of " + number + " is : " + factorial);

        sc.close();
    }

}
