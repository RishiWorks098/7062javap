package BPC;

import java.util.Scanner;

class q99 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        System.out.println("Unique elements : ");

        for (int currentIndex = 0; currentIndex < elementCount; currentIndex++) {
            int occurrenceCount = 0;

            for (int compareIndex = 0; compareIndex < elementCount; compareIndex++) {
                if (arrayElements[currentIndex] == arrayElements[compareIndex]) {
                    occurrenceCount++;
                }
            }

            if (occurrenceCount == 1) {
                System.out.print(arrayElements[currentIndex] + " ");
            }
        }

        sc.close();
    }

}
