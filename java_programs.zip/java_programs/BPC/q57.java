package BPC;

import java.util.Scanner;

class q57 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int sum = 0;

        int numbers[] = new int[5];

        System.out.println("Enter 5 numbers : ");
        for (int index = 0; index < 5; index++) {
            numbers[index] = sc.nextInt();
            sum = sum + numbers[index];
        }

        double average = (double) sum / 5;

        System.out.println("Sum : " + sum);
        System.out.println("Average : " + average);

        sc.close();
    }

}
