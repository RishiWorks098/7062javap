package BPC;

import java.util.Scanner;

class q118 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int termCount, firstTerm = 0, secondTerm = 1, nextTerm;

        System.out.println("Enter number of terms : ");
        termCount = sc.nextInt();

        System.out.println("Fibonacci series : ");

        for (int term = 1; term <= termCount; term++) {
            System.out.print(firstTerm + " ");

            nextTerm = firstTerm + secondTerm;
            firstTerm = secondTerm;
            secondTerm = nextTerm;
        }

        sc.close();
    }

}
