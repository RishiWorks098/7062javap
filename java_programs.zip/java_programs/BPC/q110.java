package BPC;

import java.util.Scanner;

class q110 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number, reverseNumber = 0;

        System.out.println("Enter an integer : ");
        number = sc.nextInt();

        while (number != 0) {
            int digit = number % 10;
            reverseNumber = reverseNumber * 10 + digit;
            number = number / 10;
        }

        System.out.println("Number in reverse order : " + reverseNumber);

        sc.close();
    }

}
