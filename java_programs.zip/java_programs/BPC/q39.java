package BPC;

import java.util.Scanner;

class q39 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double cylinderRadius, cylinderHeight, cylinderSurfaceArea;

        System.out.println("Enter radius of cylinder : ");
        cylinderRadius = sc.nextDouble();

        System.out.println("Enter height of cylinder : ");
        cylinderHeight = sc.nextDouble();

        cylinderSurfaceArea = 2 * 3.14 * cylinderRadius * (cylinderRadius + cylinderHeight);

        System.out.println("Surface area of cylinder : " + cylinderSurfaceArea);

        sc.close();
    }

}
