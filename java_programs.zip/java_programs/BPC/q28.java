package BPC;

import java.util.Scanner;

class q28 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double rectangleLength, rectangleWidth, rectangleArea;

        System.out.println("Enter length of rectangle : ");
        rectangleLength = sc.nextDouble();

        System.out.println("Enter width of rectangle : ");
        rectangleWidth = sc.nextDouble();

        rectangleArea = rectangleLength * rectangleWidth;

        System.out.println("Area of rectangle : " + rectangleArea);

        sc.close();
    }

}
