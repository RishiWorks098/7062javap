package BPC;

import java.util.Scanner;

class q32 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double parallelogramBase, parallelogramHeight, parallelogramArea;

        System.out.println("Enter base of parallelogram : ");
        parallelogramBase = sc.nextDouble();

        System.out.println("Enter height of parallelogram : ");
        parallelogramHeight = sc.nextDouble();

        parallelogramArea = parallelogramBase * parallelogramHeight;

        System.out.println("Area of parallelogram : " + parallelogramArea);

        sc.close();
    }

}
