package BPC;

class q58 {

    public static void main(String[] args) {
        System.out.println("First 5 natural numbers : ");

        for (int number = 1; number <= 5; number++) {
            System.out.print(number + " ");
        }
    }

}
