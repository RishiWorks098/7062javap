package BPC;

import java.util.Scanner;

class q108 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int tableNumber;

        System.out.println("Enter a number : ");
        tableNumber = sc.nextInt();

        System.out.println("Multiplication table of " + tableNumber + " : ");

        for (int multiplier = 1; multiplier <= 10; multiplier++) {
            System.out.println(tableNumber + " x " + multiplier + " = " + (tableNumber * multiplier));
        }

        sc.close();
    }

}
