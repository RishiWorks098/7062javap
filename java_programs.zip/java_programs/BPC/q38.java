package BPC;

import java.util.Scanner;

class q38 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double cuboidLength, cuboidWidth, cuboidHeight, cuboidSurfaceArea;

        System.out.println("Enter length of cuboid : ");
        cuboidLength = sc.nextDouble();

        System.out.println("Enter width of cuboid : ");
        cuboidWidth = sc.nextDouble();

        System.out.println("Enter height of cuboid : ");
        cuboidHeight = sc.nextDouble();

        cuboidSurfaceArea = 2 * (cuboidLength * cuboidWidth +
                                 cuboidWidth * cuboidHeight +
                                 cuboidHeight * cuboidLength);

        System.out.println("Surface area of cuboid : " + cuboidSurfaceArea);

        sc.close();
    }

}
