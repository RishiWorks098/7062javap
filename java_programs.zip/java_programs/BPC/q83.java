package BPC;

import java.util.Scanner;

class q83 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount, searchKey, foundIndex = -1;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        System.out.println("Enter element to search : ");
        searchKey = sc.nextInt();

        for (int index = 0; index < elementCount; index++) {
            if (arrayElements[index] == searchKey) {
                foundIndex = index;
                break;
            }
        }

        if (foundIndex != -1) {
            System.out.println("Element found at index : " + foundIndex);
        }
        else {
            System.out.println("Element not found");
        }

        sc.close();
    }

}
