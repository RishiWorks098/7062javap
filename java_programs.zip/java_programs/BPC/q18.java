package BPC;

import java.util.Scanner;

class q18 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String inputNumber;
        int number;

        System.out.println("Enter a number : ");
        inputNumber = sc.nextLine();

        number = Integer.parseInt(inputNumber);

        System.out.println("Integer value : " + number);

        sc.close();
    }

}
