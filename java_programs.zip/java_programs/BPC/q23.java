package BPC;

import java.util.Scanner;

class q23 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number;

        System.out.println("Enter an integer : ");
        number = sc.nextInt();

        System.out.println("Square root of " + number + " is : " + Math.sqrt(number));

        sc.close();
    }

}
