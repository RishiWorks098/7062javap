package BPC;

import java.util.Scanner;

class q37 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double coneRadius, coneHeight, coneVolume;

        System.out.println("Enter radius of cone : ");
        coneRadius = sc.nextDouble();

        System.out.println("Enter height of cone : ");
        coneHeight = sc.nextDouble();

        coneVolume = (1.0 / 3.0) * 3.14 * coneRadius * coneRadius * coneHeight;

        System.out.println("Volume of cone : " + coneVolume);

        sc.close();
    }

}
