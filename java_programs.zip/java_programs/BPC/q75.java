package BPC;

import java.util.Scanner;

class q75 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String inputString;

        System.out.println("Enter a string : ");
        inputString = sc.nextLine();

        System.out.println("Length of string : " + inputString.length());

        sc.close();
    }

}
