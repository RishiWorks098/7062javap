package BPC;

import java.util.Scanner;

class q67 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int studentMarks;

        System.out.println("Enter marks : ");
        studentMarks = sc.nextInt();

        if (studentMarks >= 90) {
            System.out.println("Grade : A");
        }
        else if (studentMarks >= 80) {
            System.out.println("Grade : B");
        }
        else if (studentMarks >= 70) {
            System.out.println("Grade : C");
        }
        else if (studentMarks >= 60) {
            System.out.println("Grade : D");
        }
        else if (studentMarks >= 40) {
            System.out.println("Grade : E");
        }
        else {
            System.out.println("Grade : F");
        }

        sc.close();
    }

}
