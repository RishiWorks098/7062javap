package BPC;

import java.util.Scanner;

class q94 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        for (int outer = 0; outer < elementCount - 1; outer++) {
            for (int inner = 0; inner < elementCount - outer - 1; inner++) {
                if (arrayElements[inner] > arrayElements[inner + 1]) {
                    int temporary = arrayElements[inner];
                    arrayElements[inner] = arrayElements[inner + 1];
                    arrayElements[inner + 1] = temporary;
                }
            }
        }

        int distinctCount = 0;
        boolean isFound = false;

        for (int index = 0; index < elementCount; index++) {
            if (index == 0 || arrayElements[index] != arrayElements[index - 1]) {
                distinctCount++;

                if (distinctCount == 2) {
                    System.out.println("Second lowest number : " + arrayElements[index]);
                    isFound = true;
                    break;
                }
            }
        }

        if (isFound == false) {
            System.out.println("Second lowest distinct number does not exist");
        }

        sc.close();
    }

}
