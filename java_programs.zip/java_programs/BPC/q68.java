package BPC;

import java.util.Scanner;

class q68 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double num1, num2, result = 0;
        char operator;

        System.out.println("Enter first number : ");
        num1 = sc.nextDouble();

        System.out.println("Enter an operator (+, -, *, /) : ");
        operator = sc.next().charAt(0);

        System.out.println("Enter second number : ");
        num2 = sc.nextDouble();

        if (operator == '+') {
            result = num1 + num2;
        }
        else if (operator == '-') {
            result = num1 - num2;
        }
        else if (operator == '*') {
            result = num1 * num2;
        }
        else if (operator == '/') {
            result = num1 / num2;
        }
        else {
            System.out.println("Invalid operator");
        }

        System.out.println("Result : " + result);

        sc.close();
    }

}
