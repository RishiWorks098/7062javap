package BPC;

import java.util.Scanner;

class q124 {

    static int sumOfDigits(int number) {
        int digitSum = 0;

        while (number > 0) {
            digitSum = digitSum + number % 10;
            number = number / 10;
        }

        return digitSum;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number;

        System.out.println("Enter a positive integer : ");
        number = sc.nextInt();

        System.out.println("Sum of digits : " + sumOfDigits(number));

        sc.close();
    }

}
