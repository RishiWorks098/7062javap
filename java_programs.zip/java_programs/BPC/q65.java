package BPC;

import java.util.Scanner;

class q65 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1, num2, num3;

        System.out.println("Enter three numbers : ");
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        num3 = sc.nextInt();

        if (num1 == num2 && num2 == num3) {
            System.out.println("All numbers are equal");
        }
        else {
            System.out.println("All numbers are not equal");
        }

        sc.close();
    }

}
