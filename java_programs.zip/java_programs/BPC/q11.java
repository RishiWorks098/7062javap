package BPC;

import java.util.Scanner;

class q11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1, num2;

        System.out.println("Enter first number : ");
        num1 = sc.nextInt();

        System.out.println("Enter second number : ");
        num2 = sc.nextInt();

        if (num1 > num2) {
            System.out.println(num1 + " is greater than " + num2);
        }
        else if (num1 < num2) {
            System.out.println(num1 + " is less than " + num2);
        }
        else {
            System.out.println("Both numbers are equal");
        }

        sc.close();
    }

}
