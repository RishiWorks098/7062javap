package BPC;

class q106 {

    public static void main(String[] args) {
        System.out.println("Numbers from 1 to 10 : ");

        for (int number = 1; number <= 10; number++) {
            System.out.print(number + " ");
        }
    }

}
