package BPC;

import java.util.Scanner;

class q30 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double triangleSide, triangleArea;

        System.out.println("Enter side of equilateral triangle : ");
        triangleSide = sc.nextDouble();

        triangleArea = (Math.sqrt(3) / 4) * triangleSide * triangleSide;

        System.out.println("Area of equilateral triangle : " + triangleArea);

        sc.close();
    }

}
