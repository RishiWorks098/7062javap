package BPC;

import java.util.Scanner;

class q95 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount, evenCount = 0, oddCount = 0;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();

            if (arrayElements[index] % 2 == 0) {
                evenCount++;
            }
            else {
                oddCount++;
            }
        }

        System.out.println("Number of even elements : " + evenCount);
        System.out.println("Number of odd elements : " + oddCount);

        sc.close();
    }

}
