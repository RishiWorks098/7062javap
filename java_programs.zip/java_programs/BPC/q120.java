package BPC;

import java.util.Scanner;

class q120 {

    static double average(double num1, double num2, double num3) {
        return (num1 + num2 + num3) / 3;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double num1, num2, num3;

        System.out.println("Enter three numbers : ");
        num1 = sc.nextDouble();
        num2 = sc.nextDouble();
        num3 = sc.nextDouble();

        System.out.println("Average of three numbers : " + average(num1, num2, num3));

        sc.close();
    }

}
