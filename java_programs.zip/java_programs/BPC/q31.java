package BPC;

import java.util.Scanner;

class q31 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double diagonal1, diagonal2, rhombusArea;

        System.out.println("Enter first diagonal of rhombus : ");
        diagonal1 = sc.nextDouble();

        System.out.println("Enter second diagonal of rhombus : ");
        diagonal2 = sc.nextDouble();

        rhombusArea = 0.5 * diagonal1 * diagonal2;

        System.out.println("Area of rhombus : " + rhombusArea);

        sc.close();
    }

}
