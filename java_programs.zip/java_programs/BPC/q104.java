package BPC;

import java.util.Scanner;

class q104 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int elementCount, searchKey;
        boolean isFound = false;

        System.out.println("Enter number of elements : ");
        elementCount = sc.nextInt();

        int arrayElements[] = new int[elementCount];

        System.out.println("Enter array elements : ");
        for (int index = 0; index < elementCount; index++) {
            arrayElements[index] = sc.nextInt();
        }

        System.out.println("Enter key element to search : ");
        searchKey = sc.nextInt();

        for (int index = 0; index < elementCount; index++) {
            if (arrayElements[index] == searchKey) {
                System.out.println("Key element found at index : " + index);
                isFound = true;
                break;
            }
        }

        if (isFound == false) {
            System.out.println("Key element not found");
        }

        sc.close();
    }

}
