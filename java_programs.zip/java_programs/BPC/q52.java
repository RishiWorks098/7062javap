package BPC;

import java.util.Scanner;

class q52 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1, num2, num3;

        System.out.println("Enter three numbers : ");
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        num3 = sc.nextInt();

        if (num1 > num2 && num1 > num3) {
            System.out.println("Greatest number : " + num1);
        }
        else if (num2 > num3) {
            System.out.println("Greatest number : " + num2);
        }
        else {
            System.out.println("Greatest number : " + num3);
        }

        sc.close();
    }

}
