package BPC;

import java.util.Scanner;

class q34 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double sphereRadius, sphereVolume;

        System.out.println("Enter radius of sphere : ");
        sphereRadius = sc.nextDouble();

        sphereVolume = (4.0 / 3.0) * 3.14 * sphereRadius * sphereRadius * sphereRadius;

        System.out.println("Volume of sphere : " + sphereVolume);

        sc.close();
    }

}
