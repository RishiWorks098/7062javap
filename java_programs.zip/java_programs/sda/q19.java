import java.util.Scanner;

class q19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < ele - 1; i++) {
            for (int j = 0; j < ele - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        int count = 0;
        boolean found = false;

        for (int i = 0; i < ele; i++) {
            if (i == 0 || arr[i] != arr[i - 1]) {
                count++;

                if (count == 2) {
                    System.out.println("Second smallest number : " + arr[i]);
                    found = true;
                    break;
                }
            }
        }

        if (found == false) {
            System.out.println("Second smallest distinct number does not exist");
        }
        sc.close();
    }
}
