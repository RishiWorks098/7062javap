import java.util.Scanner;

class q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];
        int copy[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < ele; i++) {
            copy[i] = arr[i];
        }

        System.out.println("Copied array : ");
        for (int i = 0; i < ele; i++) {
            System.out.print(copy[i] + " ");
        }
        sc.close();
    }
}
