import java.util.Scanner;

class q12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele, sum = 0;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
            sum = sum + arr[i];
        }

        System.out.println("Sum of array elements : " + sum);
        sc.close();
    }
}
