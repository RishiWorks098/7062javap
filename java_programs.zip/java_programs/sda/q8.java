import java.util.Scanner;

class q8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Elements at odd positions : ");
        for (int i = 0; i < ele; i = i + 2) {
            System.out.print(arr[i] + " ");
        }
        sc.close();
    }
}
