import java.util.Scanner;

class q4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Duplicate elements : ");
        boolean found = false;

        for (int i = 0; i < ele; i++) {
            boolean printed = false;

            for (int j = 0; j < i; j++) {
                if (arr[i] == arr[j]) {
                    printed = true;
                    break;
                }
            }

            if (printed == false) {
                for (int j = i + 1; j < ele; j++) {
                    if (arr[i] == arr[j]) {
                        System.out.println(arr[i]);
                        found = true;
                        break;
                    }
                }
            }
        }

        if (found == false) {
            System.out.println("No duplicate elements");
        }
        sc.close();
    }
}
