import java.util.Scanner;

class q11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Number of elements present in array : " + arr.length);
        sc.close();
    }
}
