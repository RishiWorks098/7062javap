import java.util.Scanner;

class q3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele, pos;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Enter number of positions to rotate left : ");
        pos = sc.nextInt();

        if (ele > 0) {
            pos = pos % ele;
            for (int i = 0; i < pos; i++) {
                int first = arr[0];

                for (int j = 0; j < ele - 1; j++) {
                    arr[j] = arr[j + 1];
                }

                arr[ele - 1] = first;
            }
        }

        System.out.println("Array after left rotation : ");
        for (int i = 0; i < ele; i++) {
            System.out.print(arr[i] + " ");
        }
        sc.close();
    }
}
