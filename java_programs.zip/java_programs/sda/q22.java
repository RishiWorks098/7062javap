import java.util.Scanner;

class q22 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Even numbers : ");
        for (int i = 0; i < ele; i++) {
            if (arr[i] % 2 == 0) {
                System.out.print(arr[i] + " ");
            }
        }

        System.out.println();
        System.out.println("Odd numbers : ");
        for (int i = 0; i < ele; i++) {
            if (arr[i] % 2 != 0) {
                System.out.print(arr[i] + " ");
            }
        }
        sc.close();
    }
}
