import java.util.Scanner;

class q9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        int largest = arr[0];

        for (int i = 1; i < ele; i++) {
            if (arr[i] > largest) {
                largest = arr[i];
            }
        }

        System.out.println("Largest element : " + largest);
        sc.close();
    }
}
