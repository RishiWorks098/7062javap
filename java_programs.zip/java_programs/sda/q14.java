import java.util.Scanner;

class q14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < ele - 1; i++) {
            for (int j = 0; j < ele - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        System.out.println("Array in ascending order : ");
        for (int i = 0; i < ele; i++) {
            System.out.print(arr[i] + " ");
        }
        sc.close();
    }
}
