import java.util.Scanner;

class q13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int ele, pos;

        System.out.println("Enter number of elements : ");
        ele = sc.nextInt();

        int arr[] = new int[ele];

        System.out.println("Enter array elements : ");
        for (int i = 0; i < ele; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Enter number of positions to rotate right : ");
        pos = sc.nextInt();

        if (ele > 0) {
            pos = pos % ele;
            for (int i = 0; i < pos; i++) {
                int last = arr[ele - 1];

                for (int j = ele - 1; j > 0; j--) {
                    arr[j] = arr[j - 1];
                }

                arr[0] = last;
            }
        }

        System.out.println("Array after right rotation : ");
        for (int i = 0; i < ele; i++) {
            System.out.print(arr[i] + " ");
        }
        sc.close();
    }
}
