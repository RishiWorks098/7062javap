package packages;

class Q2 {
    public static void main(String[] args) {
        java.util.Date d = new java.util.Date();

        System.out.println("Current Date : " + d);
    }
}