package packages;

import packages.q6pack.class1;
import packages.q6pack.class2;
import packages.q6pack.class3;
import packages.q6pack.class4;

class q6 {
    public static void main(String[] args) {
        class1 C1 = new class1();
        class2 C2 = new class2();
        class3 C3 = new class3();
        class4 C4 = new class4();

        C1.display();
        C2.display();
        C3.display();
        C4.display();
    }
}