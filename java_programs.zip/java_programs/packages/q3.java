package packages;
import java.util.Date;

class Q3 extends Date {
    public static void main(String[] args) {
        Q3 d = new Q3();

        System.out.println("Current Date : " + d);
    }
}