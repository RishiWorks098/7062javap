package packages;

class Q4 extends java.util.Date {
    public static void main(String[] args) {
        Q4 d = new Q4();

        System.out.println("Current Date : " + d);
    }
}