package packages;
import java.util.Date;

class Q1 {
    public static void main(String[] args) {
        Date d = new Date();

        System.out.println("Current Date : " + d);
    }
}