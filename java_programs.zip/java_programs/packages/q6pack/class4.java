package packages.q6pack;

public class class4 {
    public void display() {
        System.out.println("this is the Class 4");
    }
}