package packages.q6pack;

public class class1 {
    public void display() {
        System.out.println("this is the Class 1");
    }
}