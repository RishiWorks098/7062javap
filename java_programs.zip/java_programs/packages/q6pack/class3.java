package packages.q6pack;

public class class3 {
    public void display() {
        System.out.println("this is the Class 3");
    }
}