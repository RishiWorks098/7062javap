package packages.q6pack;

public class class2 {
    public void display() {
        System.out.println("this is the Class 2");
    }
}