package packages.q8pack;

public class class1 {
    protected int a = 100;

    protected void display() {
        System.out.println("Value : " + a);
    }
}