package packages;
import packages.q8pack.class1;


class q8 extends class1 {
    public static void main(String[] args) {
        q8 obj1 = new q8();

        System.out.println("Value : " + obj1.a);
        obj1.display();
    }
}
