package OOPS;

class Person {
    String name ; 
    int age;

    public Person(String name , int age) {
        this.name = name ;
        this.age = age;

    }
    public static void main(String[] args) {
        Person R7062 = new Person("Rishipal", 19);
        Person R7034 = new Person("Neeraj" , 20);

        System.out.println("Name : " + R7062.name +  " Age : " + R7062.age);
        System.out.println("Name : " + R7034.name +  " Age : " + R7034.age);

    }
    
}
