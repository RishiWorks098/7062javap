package OOPS;

class Employee {
    String name ; 
    String job_title;
    float salary;

    public Employee(String name ,String job_title, int salary) {
        this.name = name ;
        this.job_title = job_title;
        this.salary = salary;
    }
    void calcSalary() {
        System.out.println("Name :" + this.name + " Salary :" + this.salary);
    }
    void upSalary(float salary){
        System.out.print("Salary update from : " + this.salary );
        this.salary = salary;
        System.out.print(" to " + this.salary );
    }


    
    public static void main(String[] args) {
        Employee E1 = new Employee("Rohan", "SE" , 100000);
        Employee E2 = new Employee("John", "Designer" , 50000);

        E1.calcSalary();
        E1.upSalary(100);
        

    }
    
}
