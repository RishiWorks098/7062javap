package OOPS;

class Inventory {
    String pname ; 
    int quantity;

    public Inventory ( String pname ,int quantity) {
        this.pname = pname ;
        this.quantity = quantity;
    }
    void addPorduct(int addq) {
        quantity = quantity + addq;
        
    }
    void rmProduct(int rmq){
       quantity = quantity - rmq;

    }

    void checkQuantity(){
        if (quantity < 500) {
            System.out.println("Quantity is less than 200" + "(" +quantity+")");
        }
        else{
            System.out.println("Quantity is more than 200"+ "(" +quantity+")");
        }

    }


    
    public static void main(String[] args) {
        Inventory P1 = new Inventory("Shampoo" , 1000);
        Inventory P2 = new Inventory("Soap", 5000);

        P1.addPorduct(200);

        P2.rmProduct(4900);

        P1.checkQuantity();
        P2.checkQuantity();
        

    }
    
}
