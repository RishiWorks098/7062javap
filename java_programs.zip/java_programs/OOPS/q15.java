package OOPS;

import java.util.Random;

class MusicLibrary {
    String[] songs = new String[100];
    int count = 0;

    void addSong(String song) {
        if (count < songs.length) {
            songs[count] = song;
            count++;
        } else {
            System.out.println("Music library is full");
        }
    }

    void removeSong(String song) {
        for (int i = 0; i < count; i++) {
            if (songs[i].equals(song)) {
                for (int j = i; j < count - 1; j++) {
                    songs[j] = songs[j + 1];
                }

                count--;
                songs[count] = null;
                return;
            }
        }

        System.out.println("Song not found");
    }

    void displaySongs() {
        for (int i = 0; i < count; i++) {
            System.out.println("Song : " + songs[i]);
        }
    }

    void playRandomSong() {
        if (count == 0) {
            System.out.println("No songs in the library");
        } else {
            Random random = new Random();
            int index = random.nextInt(count);

            System.out.println("Now playing : " + songs[index]);
        }
    }

    public static void main(String[] args) {
        MusicLibrary library = new MusicLibrary();

        library.addSong("Tum Hi Ho");
        library.addSong("Perfect");
        library.addSong("Believer");

        System.out.println("BEFORE REMOVING");
        library.displaySongs();

        library.removeSong("Perfect");

        System.out.println("AFTER REMOVING");
        library.displaySongs();

        System.out.println("PLAYING A RANDOM SONG");
        library.playRandomSong();
    }
}