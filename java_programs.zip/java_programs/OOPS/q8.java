package OOPS;

class TrafficLight {
    String color ; 
    int duration;

    public TrafficLight(String color ,int duration) {
        this.color = color ;
        this.duration = duration;
    }
    void chColor(int choice) {

        switch (choice) {
            case 1:
                
                System.out.println("You selected Option 1 . Color changed to Red");
                color= "RED";
                break; 

            case 2:
                System.out.println("You selected Option 2. Color changed to Yellow");
                color= "YELLOW";
                break; 

            case 3:
                System.out.println("You selected Option 3.Color changed to Green");
                color= "GREEN";
                break;

            default:
                System.out.println("Invalid choice. Please select 1, 2, or 3.");
                break;
        }
    }


    
    public static void main(String[] args) {
        TrafficLight L1Light = new TrafficLight("RED", 5);
        System.out.println("Lights before changing : " + L1Light.color);

        L1Light.chColor(3);
        System.out.println("Lights after changing : " + L1Light.color);

        System.out.println("Current light status : " + L1Light.color);


        

    }
    
}
