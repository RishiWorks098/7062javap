package OOPS;

class Student {
    int rollNo;
    String name;

    Student(int r, String n) {
        rollNo = r;
        name = n;
    }

    void display() {
        System.out.println("Roll Number: " + rollNo);
        System.out.println("Name: " + name);
    }
}

class q21 {
    public static void main(String[] args) {
        Student obj = new Student(101, "Rahul");

        obj.display();
    }
}
