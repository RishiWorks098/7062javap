package OOPS;

class Student {
    String name ; 
    int grade;
    String course;


    public Student(String name ,int grade , String course) {
        this.name = name ;
        this.grade = grade;
        this.course = course;
    }

    void addCourse(String course){
        this.course = course;

    }
    void rmCourse() {
        this.course = " "; 
       
    }


    
    public static void main(String[] args) {
        Student S1 = new Student("Rishipal", 12 ,"PCM");
        System.out.println("S1 info Before changing : " + S1.name + " " + S1.grade + " " + S1.course);

        S1.addCourse("IT");

        System.out.println("S1 info After changing : " + S1.name + " " + S1.grade + " " + S1.course);

        S1.rmCourse();
        System.out.println("S1 info After Deleting Course : " + S1.name + " " + S1.grade + " " + S1.course);


        

    }
    
}
