package OOPS;

class Dog {
    String name ; 
    String breed;

    public Dog(String name ,String breed) {
        this.name = name ;
        this.breed = breed;
    }
    void setDogname(String name) {
        this.name = name; //change name 
    }
    void setDogbreed(String breed) {
        this.breed = breed; //change breed 
    }



    
    public static void main(String[] args) {
        Dog d1 = new Dog("lucy", "Golden Retriever");
        Dog d2 = new Dog("rocky" , "Pitbull");

        System.out.println("BEFORE CHANGING");

        System.out.println("Name : " + d1.name +  " Breed : " + d1.breed);
        System.out.println("Name : " + d2.name +  " Breed : " + d2.breed);

        d1.setDogname("lyra");
        d1.setDogbreed("Hound");

        d2.setDogname("luna");
        d2.setDogbreed("Labrador");

        System.out.println("AFTER CHANGING");


        System.out.println("Name : " + d1.name +  " Breed : " + d1.breed);
        System.out.println("Name : " + d2.name +  " Breed : " + d2.breed);

    }
    
}
