package OOPS;

class q4 {
    public static void main(String[] args) {
        double radius = 5;

        double area = 3.14 * radius * radius;
        double circumference = 2 * 3.14 * radius;

        System.out.println("Area of Circle: " + area);
        System.out.println("Circumference of Circle: " + circumference);
    }
}
