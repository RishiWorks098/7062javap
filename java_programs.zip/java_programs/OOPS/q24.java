package OOPS;

class Area {
    void calculateArea(double radius) {
        double area = 3.14 * radius * radius;
        System.out.println("Area of Circle: " + area);
    }

    void calculateArea(double length, double width) {
        double area = length * width;
        System.out.println("Area of Rectangle: " + area);
    }
}

class q24 {
    public static void main(String[] args) {
        Area obj = new Area();

        obj.calculateArea(5);
        obj.calculateArea(10, 5);
    }
}
