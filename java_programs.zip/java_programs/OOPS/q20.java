package OOPS;

class Student {
    int rollNo;
    String name;

    Student() {
        rollNo = 101;
        name = "Rahul";
    }

    void display() {
        System.out.println("Roll Number: " + rollNo);
        System.out.println("Name: " + name);
    }
}

class q20 {
    public static void main(String[] args) {
        Student obj = new Student();

        obj.display();
    }
}
