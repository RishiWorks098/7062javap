package interfaces;

interface Sortable {
    void sort(int[] numbers);
}

class BubbleSort implements Sortable {
    public void sort(int[] numbers) {
        for (int outer = 0; outer < numbers.length - 1; outer++) {
            for (int inner = 0; inner < numbers.length - outer - 1; inner++) {
                if (numbers[inner] > numbers[inner + 1]) {
                    int temporary = numbers[inner];
                    numbers[inner] = numbers[inner + 1];
                    numbers[inner + 1] = temporary;
                }
            }
        }
    }
}

class SelectionSort implements Sortable {
    public void sort(int[] numbers) {
        for (int currentIndex = 0; currentIndex < numbers.length - 1; currentIndex++) {
            int minimumIndex = currentIndex;

            for (int nextIndex = currentIndex + 1; nextIndex < numbers.length; nextIndex++) {
                if (numbers[nextIndex] < numbers[minimumIndex]) {
                    minimumIndex = nextIndex;
                }
            }

            int temporary = numbers[currentIndex];
            numbers[currentIndex] = numbers[minimumIndex];
            numbers[minimumIndex] = temporary;
        }
    }
}

class q7 {
    public static void main(String[] args) {
        int[] bubbleNumbers = {5, 2, 9, 1, 7};
        int[] selectionNumbers = {8, 3, 6, 4, 2};

        Sortable bubbleSort = new BubbleSort();
        Sortable selectionSort = new SelectionSort();

        bubbleSort.sort(bubbleNumbers);
        selectionSort.sort(selectionNumbers);

        System.out.println("Bubble sorted array : ");
        for (int number : bubbleNumbers) {
            System.out.print(number + " ");
        }

        System.out.println();

        System.out.println("Selection sorted array : ");
        for (int number : selectionNumbers) {
            System.out.print(number + " ");
        }
    }
}
