package interfaces;

interface Searchable {
    boolean search(String keyword);
}

class Document implements Searchable {
    String documentText;

    Document(String documentText) {
        this.documentText = documentText;
    }

    public boolean search(String keyword) {
        return documentText.contains(keyword);
    }
}

class WebPage implements Searchable {
    String pageText;

    WebPage(String pageText) {
        this.pageText = pageText;
    }

    public boolean search(String keyword) {
        return pageText.contains(keyword);
    }
}

class q9 {
    public static void main(String[] args) {
        Document document = new Document("Java is a popular programming language");
        WebPage webPage = new WebPage("Learn Java programming online");

        String keyword = "Java";

        if (document.search(keyword)) {
            System.out.println("Keyword found in document");
        }
        else {
            System.out.println("Keyword not found in document");
        }

        if (webPage.search(keyword)) {
            System.out.println("Keyword found in web page");
        }
        else {
            System.out.println("Keyword not found in web page");
        }
    }
}
