package interfaces;

interface Sortable {
    void sort(int[] numbers);
}

class QuickSort implements Sortable {
    public void sort(int[] numbers) {
        for (int outer = 0; outer < numbers.length - 1; outer++) {
            for (int inner = 0; inner < numbers.length - outer - 1; inner++) {
                if (numbers[inner] < numbers[inner + 1]) {
                    int temporary = numbers[inner];
                    numbers[inner] = numbers[inner + 1];
                    numbers[inner + 1] = temporary;
                }
            }
        }
    }
}

class MergeSort implements Sortable {
    public void sort(int[] numbers) {
        for (int outer = 0; outer < numbers.length - 1; outer++) {
            int maximumIndex = outer;

            for (int nextIndex = outer + 1; nextIndex < numbers.length; nextIndex++) {
                if (numbers[nextIndex] > numbers[maximumIndex]) {
                    maximumIndex = nextIndex;
                }
            }

            int temporary = numbers[outer];
            numbers[outer] = numbers[maximumIndex];
            numbers[maximumIndex] = temporary;
        }
    }
}

class q11 {
    public static void main(String[] args) {
        int[] quickSortNumbers = {4, 9, 2, 8, 1};
        int[] mergeSortNumbers = {7, 3, 10, 5, 6};

        Sortable quickSort = new QuickSort();
        Sortable mergeSort = new MergeSort();

        quickSort.sort(quickSortNumbers);
        mergeSort.sort(mergeSortNumbers);

        System.out.println("Quick sorted array in descending order : ");
        for (int number : quickSortNumbers) {
            System.out.print(number + " ");
        }

        System.out.println();

        System.out.println("Merge sorted array in descending order : ");
        for (int number : mergeSortNumbers) {
            System.out.print(number + " ");
        }
    }
}
