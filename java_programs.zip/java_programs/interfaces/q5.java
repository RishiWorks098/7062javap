package interfaces;

interface Resizable {
    void resizeWidth(int width);

    void resizeHeight(int height);
}

class Rectangle implements Resizable {
    int width;
    int height;

    Rectangle(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void resizeWidth(int width) {
        this.width = width;
        System.out.println("Rectangle width resized to : " + width);
    }

    public void resizeHeight(int height) {
        this.height = height;
        System.out.println("Rectangle height resized to : " + height);
    }

    void displaySize() {
        System.out.println("Rectangle size : " + width + " x " + height);
    }
}

class q5 {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle(10, 5);

        rectangle.displaySize();

        rectangle.resizeWidth(20);
        rectangle.resizeHeight(15);

        rectangle.displaySize();
    }
}
