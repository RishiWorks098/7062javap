package interfaces;

import java.util.ArrayList;

interface Account {
    void deposit(double amount);

    void withdraw(double amount);

    double calculateInterest();

    void viewBalance();
}

class SavingsAccount implements Account {
    String accountHolderName;
    double balance;
    double interestRate;

    SavingsAccount(String accountHolderName, double balance, double interestRate) {
        this.accountHolderName = accountHolderName;
        this.balance = balance;
        this.interestRate = interestRate;
    }

    public void deposit(double amount) {
        balance = balance + amount;
        System.out.println(amount + " deposited in savings account");
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance = balance - amount;
            System.out.println(amount + " withdrawn from savings account");
        }
        else {
            System.out.println("Insufficient balance in savings account");
        }
    }

    public double calculateInterest() {
        return balance * interestRate / 100;
    }

    public void viewBalance() {
        System.out.println("Savings account balance of " + accountHolderName + " : " + balance);
    }

    void addInterest() {
        double interest = calculateInterest();
        balance = balance + interest;
        System.out.println("Interest added : " + interest);
    }
}

class CurrentAccount implements Account {
    String accountHolderName;
    double balance;
    double overdraftLimit;

    CurrentAccount(String accountHolderName, double balance, double overdraftLimit) {
        this.accountHolderName = accountHolderName;
        this.balance = balance;
        this.overdraftLimit = overdraftLimit;
    }

    public void deposit(double amount) {
        balance = balance + amount;
        System.out.println(amount + " deposited in current account");
    }

    public void withdraw(double amount) {
        if (amount <= balance + overdraftLimit) {
            balance = balance - amount;
            System.out.println(amount + " withdrawn from current account");
        }
        else {
            System.out.println("Withdrawal amount exceeds overdraft limit");
        }
    }

    public double calculateInterest() {
        return 0;
    }

    public void viewBalance() {
        System.out.println("Current account balance of " + accountHolderName + " : " + balance);
    }
}

class Bank {
    ArrayList<Account> accounts = new ArrayList<Account>();

    void addAccount(Account account) {
        accounts.add(account);
        System.out.println("Account added to bank");
    }

    void showAllAccounts() {
        for (Account account : accounts) {
            account.viewBalance();
        }
    }
}

class q4 {
    public static void main(String[] args) {
        Bank bank = new Bank();

        SavingsAccount savingsAccount = new SavingsAccount("Rahul", 5000, 5);
        CurrentAccount currentAccount = new CurrentAccount("Priya", 10000, 2000);

        bank.addAccount(savingsAccount);
        bank.addAccount(currentAccount);

        savingsAccount.deposit(2000);
        savingsAccount.withdraw(1000);
        savingsAccount.addInterest();
        savingsAccount.viewBalance();

        currentAccount.deposit(3000);
        currentAccount.withdraw(12000);
        currentAccount.viewBalance();

        bank.showAllAccounts();
    }
}
