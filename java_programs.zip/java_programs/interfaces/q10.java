package interfaces;

interface Encryptable {
    String encrypt(String data);

    String decrypt(String encryptedData);
}

class AES implements Encryptable {
    public String encrypt(String data) {
        String encryptedData = "";

        for (int index = 0; index < data.length(); index++) {
            encryptedData = encryptedData + (char) (data.charAt(index) + 1);
        }

        return encryptedData;
    }

    public String decrypt(String encryptedData) {
        String decryptedData = "";

        for (int index = 0; index < encryptedData.length(); index++) {
            decryptedData = decryptedData + (char) (encryptedData.charAt(index) - 1);
        }

        return decryptedData;
    }
}

class RSA implements Encryptable {
    public String encrypt(String data) {
        String encryptedData = "";

        for (int index = 0; index < data.length(); index++) {
            encryptedData = encryptedData + (char) (data.charAt(index) + 2);
        }

        return encryptedData;
    }

    public String decrypt(String encryptedData) {
        String decryptedData = "";

        for (int index = 0; index < encryptedData.length(); index++) {
            decryptedData = decryptedData + (char) (encryptedData.charAt(index) - 2);
        }

        return decryptedData;
    }
}

class q10 {
    public static void main(String[] args) {
        String originalData = "Hello";

        Encryptable aes = new AES();
        Encryptable rsa = new RSA();

        String aesEncryptedData = aes.encrypt(originalData);
        String rsaEncryptedData = rsa.encrypt(originalData);

        System.out.println("AES encrypted data : " + aesEncryptedData);
        System.out.println("AES decrypted data : " + aes.decrypt(aesEncryptedData));

        System.out.println("RSA encrypted data : " + rsaEncryptedData);
        System.out.println("RSA decrypted data : " + rsa.decrypt(rsaEncryptedData));
    }
}
